﻿using System;
using System.Data;
using Microsoft.Data.SqlClient;

namespace GestionCine_WindowsForms;

public class ClienteDAO
{
    public DataTable ObtenerClientes()
    {
        return Database.ExecuteQuerySP("sp_ObtenerClientes");
    }

    public bool InsertarCliente(Cliente cliente)
    {
        SqlParameter[] parameters = new[]
        {
            new SqlParameter("@Nombre", cliente.Nombre),
            new SqlParameter("@Apellido", cliente.Apellido),
            new SqlParameter("@Correo", cliente.Correo),
            new SqlParameter("@Telefono", (object)cliente.Telefono ?? DBNull.Value),
            new SqlParameter("@FechaNacimiento", cliente.FechaNacimiento)
        };

        return Database.ExecuteNonQuerySP("sp_InsertarCliente", parameters);
    }

    public bool EliminarClienteLogico(int clienteId)
    {
        SqlParameter[] parameters = new[]
        {
            new SqlParameter("@ClienteId", clienteId)
        };

        return Database.ExecuteNonQuerySP("sp_EliminarClienteLogic", parameters);
    }
}