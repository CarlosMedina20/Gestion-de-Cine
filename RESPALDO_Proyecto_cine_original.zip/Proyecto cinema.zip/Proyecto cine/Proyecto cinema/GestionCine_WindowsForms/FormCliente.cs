﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace GestionCine_WindowsForms;

public class FormCliente : Form
{
    private readonly TextBox txtNombre = new() { Width = 200 };
    private readonly TextBox txtApellido = new() { Width = 200 };
    private readonly TextBox txtCorreo = new() { Width = 200 };
    private readonly TextBox txtTelefono = new() { Width = 200 };
    private readonly DateTimePicker dtpFechaNac = new() { Width = 200, Format = DateTimePickerFormat.Short };

    public Cliente? ClienteCreado { get; private set; }

    public FormCliente()
    {
        Text = "Registrar Nuevo Cliente";
        Size = new Size(360, 320);
        StartPosition = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;

        var panel = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(15),
            ColumnCount = 2,
            RowCount = 6
        };

        panel.Controls.Add(new Label { Text = "Nombre:", AutoSize = true }, 0, 0);
        panel.Controls.Add(txtNombre, 1, 0);

        panel.Controls.Add(new Label { Text = "Apellido:", AutoSize = true }, 0, 1);
        panel.Controls.Add(txtApellido, 1, 1);

        panel.Controls.Add(new Label { Text = "Correo:", AutoSize = true }, 0, 2);
        panel.Controls.Add(txtCorreo, 1, 2);

        panel.Controls.Add(new Label { Text = "Teléfono:", AutoSize = true }, 0, 3);
        panel.Controls.Add(txtTelefono, 1, 3);

        panel.Controls.Add(new Label { Text = "F. Nacimiento:", AutoSize = true }, 0, 4);
        panel.Controls.Add(dtpFechaNac, 1, 4);

        var btnGuardar = new Button { Text = "Guardar", Width = 90, Height = 30, DialogResult = DialogResult.OK };
        btnGuardar.Click += BtnGuardar_Click;

        var btnCancelar = new Button { Text = "Cancelar", Width = 90, Height = 30, DialogResult = DialogResult.Cancel };

        var flowBtns = new FlowLayoutPanel { FlowDirection = FlowDirection.RightToLeft, Dock = DockStyle.Fill };
        flowBtns.Controls.Add(btnCancelar);
        flowBtns.Controls.Add(btnGuardar);

        panel.Controls.Add(flowBtns, 1, 5);

        Controls.Add(panel);
    }

    private void BtnGuardar_Click(object? sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(txtNombre.Text) || string.IsNullOrWhiteSpace(txtApellido.Text) || string.IsNullOrWhiteSpace(txtCorreo.Text))
        {
            MessageBox.Show("Por favor completa los campos obligatorios (Nombre, Apellido, Correo).", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            DialogResult = DialogResult.None;
            return;
        }

        ClienteCreado = new Cliente
        {
            Nombre = txtNombre.Text.Trim(),
            Apellido = txtApellido.Text.Trim(),
            Correo = txtCorreo.Text.Trim(),
            Telefono = txtTelefono.Text.Trim(),
            FechaNacimiento = dtpFechaNac.Value
        };
    }
}