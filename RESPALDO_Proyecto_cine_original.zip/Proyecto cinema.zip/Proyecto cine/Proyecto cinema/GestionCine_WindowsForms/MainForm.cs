using System;
using System.Drawing;
using System.Windows.Forms;

namespace GestionCine_WindowsForms;

public class MainForm : Form
{
    private readonly DataGridView grid = new();
    private readonly Label status = new();
    private readonly ClienteDAO clienteDAO = new();
    private string tablaActual = string.Empty;

    public MainForm()
    {
        Text = "Gestión de Cine - Arquitectura en Capas";
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(1000, 650);
        Size = new Size(1200, 720);

        var title = new Label
        {
            Text = "SISTEMA DE GESTIÓN DE CINE",
            Dock = DockStyle.Top,
            Height = 60,
            TextAlign = ContentAlignment.MiddleCenter,
            Font = new Font("Segoe UI", 20, FontStyle.Bold)
        };

        var menu = new FlowLayoutPanel
        {
            Dock = DockStyle.Top,
            Height = 60,
            Padding = new Padding(10),
            WrapContents = false,
            AutoScroll = true
        };

        // Botones Principales
        Button(menu, "Probar conexión", (_, _) => TestConnection());
        Button(menu, "Películas", (_, _) => CargarPeliculas());
        Button(menu, "Clientes", (_, _) => CargarClientes());
        Button(menu, "Nuevo Cliente", (_, _) => AgregarCliente());
        Button(menu, "Inactivar Cliente", (_, _) => EliminarCliente());
        Button(menu, "Productos", (_, _) => LoadData("Productos", "SELECT ProductoId,Nombre,Categoria,Precio,Stock,Descripcion,Activo FROM Producto WHERE Activo=1 ORDER BY ProductoId"));
        Button(menu, "Funciones", (_, _) => LoadData("Funciones", "SELECT f.FuncionId,p.Titulo AS Pelicula,s.Nombre AS Sala,f.Fecha,f.Hora,f.Formato,f.PrecioBase,f.Activo FROM Funcion f INNER JOIN Pelicula p ON p.PeliculaId=f.PeliculaId INNER JOIN Sala s ON s.SalaId=f.SalaId ORDER BY f.Fecha,f.Hora"));
        Button(menu, "Ventas", (_, _) => LoadData("Ventas", "SELECT v.VentaId,v.CantidadBoletos,v.CantidadProducto,v.Subtotal,v.Impuesto,v.Total,v.FormaPago,v.FechaVenta FROM Venta v ORDER BY v.FechaVenta DESC"));

        grid.Dock = DockStyle.Fill;
        grid.ReadOnly = true;
        grid.AllowUserToAddRows = false;
        grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

        status.Text = "Listo. Selecciona una opción.";
        status.Dock = DockStyle.Bottom;
        status.Height = 35;
        status.Padding = new Padding(10);

        Controls.Add(grid);
        Controls.Add(status);
        Controls.Add(menu);
        Controls.Add(title);
    }

    private static void Button(FlowLayoutPanel p, string text, EventHandler action)
    {
        var b = new Button
        {
            Text = text,
            Width = 135,
            Height = 40,
            Margin = new Padding(3),
            Font = new Font("Segoe UI", 9, FontStyle.Bold)
        };
        b.Click += action;
        p.Controls.Add(b);
    }

    private void TestConnection()
    {
        if (Database.TestConnection(out var msg))
            MessageBox.Show(msg, "Gestión de Cine", MessageBoxButtons.OK, MessageBoxIcon.Information);
        else
            MessageBox.Show("No se pudo conectar a SQL Server.\n\n" + msg, "Conexión", MessageBoxButtons.OK, MessageBoxIcon.Warning);
    }

    private void CargarClientes()
    {
        try
        {
            grid.DataSource = clienteDAO.ObtenerClientes();
            tablaActual = "Clientes";
            status.Text = $"Clientes activos cargados desde SP: {grid.Rows.Count} registro(s).";
        }
        catch (Exception ex)
        {
            MessageBox.Show("Error al cargar clientes: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void CargarPeliculas()
    {
        try
        {
            grid.DataSource = Database.ExecuteQuerySP("sp_ObtenerPeliculas");
            tablaActual = "Películas";
            status.Text = $"Películas cargadas desde SP: {grid.Rows.Count} registro(s).";
        }
        catch (Exception ex)
        {
            MessageBox.Show("Error al cargar películas: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void AgregarCliente()
    {
        using var form = new FormCliente();
        if (form.ShowDialog() == DialogResult.OK && form.ClienteCreado != null)
        {
            try
            {
                if (clienteDAO.InsertarCliente(form.ClienteCreado))
                {
                    MessageBox.Show("Cliente registrado exitosamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    CargarClientes();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al insertar cliente: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }

    private void EliminarCliente()
    {
        if (tablaActual != "Clientes" || grid.CurrentRow == null)
        {
            MessageBox.Show("Selecciona primero la opción 'Clientes' y marca una fila para inactivar.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        int clienteId = Convert.ToInt32(grid.CurrentRow.Cells["ClienteId"].Value);
        string nombre = grid.CurrentRow.Cells["Nombre"].Value.ToString() + " " + grid.CurrentRow.Cells["Apellido"].Value.ToString();

        if (MessageBox.Show($"¿Deseas inactivar al cliente {nombre}?", "Confirmar Eliminación", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
        {
            try
            {
                if (clienteDAO.EliminarClienteLogico(clienteId))
                {
                    MessageBox.Show("Cliente inactivado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    CargarClientes();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al inactivar cliente: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }

    private void LoadData(string name, string sql)
    {
        try
        {
            var table = Database.GetTable(sql);
            grid.DataSource = table;
            tablaActual = name;
            status.Text = $"{name}: {table.Rows.Count} registro(s).";
        }
        catch (Exception ex)
        {
            MessageBox.Show("No se pudo cargar " + name + ".\n\n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}