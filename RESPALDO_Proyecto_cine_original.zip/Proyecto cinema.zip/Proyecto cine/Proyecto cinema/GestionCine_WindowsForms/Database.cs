using System;
using System.Data;
using Microsoft.Data.SqlClient;

namespace GestionCine_WindowsForms;

public static class Database
{
    public static string ConnectionString =
    "Data Source=localhost\\SQLEXPRESS;Initial Catalog=GestionCineDB;Integrated Security=True;TrustServerCertificate=True;";

    public static DataTable GetTable(string sql)
    {
        using var cn = new SqlConnection(ConnectionString);
        using var da = new SqlDataAdapter(sql, cn);
        var table = new DataTable();
        da.Fill(table);
        return table;
    }

    public static bool TestConnection(out string message)
    {
        try
        {
            using var cn = new SqlConnection(ConnectionString);
            cn.Open();
            message = "Conexión correcta con GestionCineDB.";
            return true;
        }
        catch (Exception ex)
        {
            message = ex.Message;
            return false;
        }
    }

    /* =========================================================
       NUEVOS MÉTODOS PARA EJECUTAR PROCEDIMIENTOS ALMACENADOS
       ========================================================= */

    // Para ejecutar SP que devuelven tablas (SELECT)
    public static DataTable ExecuteQuerySP(string spName, SqlParameter[]? parameters = null)
    {
        using var cn = new SqlConnection(ConnectionString);
        using var cmd = new SqlCommand(spName, cn);
        cmd.CommandType = CommandType.StoredProcedure;

        if (parameters != null)
            cmd.Parameters.AddRange(parameters);

        using var da = new SqlDataAdapter(cmd);
        var table = new DataTable();
        da.Fill(table);
        return table;
    }

    // Para ejecutar SP de inserción, edición o eliminación (INSERT/UPDATE/DELETE)
    public static bool ExecuteNonQuerySP(string spName, SqlParameter[] parameters)
    {
        using var cn = new SqlConnection(ConnectionString);
        using var cmd = new SqlCommand(spName, cn);
        cmd.CommandType = CommandType.StoredProcedure;

        if (parameters != null)
            cmd.Parameters.AddRange(parameters);

        cn.Open();
        return cmd.ExecuteNonQuery() > 0;
    }
}